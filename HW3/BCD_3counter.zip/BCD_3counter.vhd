library IEEE;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

entity BCD_3counter is
    port(
        clk       : in  std_logic;
        reset     : in  std_logic;
        M         : in  std_logic;
        Q         : out std_logic_vector(11 downto 0);
        carry_out : out std_logic
    );
end BCD_3counter;

architecture BCD_3counter of BCD_3counter is
    signal C1, C2 : std_logic;
begin
    U0 : entity work.BCD_counter
        port map(
            clk       => clk,
            reset     => reset,
            M         => M,
            carry_in  => '1',
            carry_out => C1,
            Q         => Q(3 downto 0)
        );
    U1 : entity work.BCD_counter
        port map(
            clk       => clk,
            reset     => reset,
            M         => M,
            carry_in  => C1,
            carry_out => C2,
            Q         => Q(7 downto 4)
        );
    U2 : entity work.BCD_counter
        port map(
            clk       => clk,
            reset     => reset,
            M         => M,
            carry_in  => C2,
            carry_out => carry_out,
            Q         => Q(11 downto 8)
        );

end BCD_3counter;