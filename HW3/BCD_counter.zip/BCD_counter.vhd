library IEEE;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

entity BCD_counter is
	port(
			clk:in std_logic;
			reset:in std_logic;
			M:in std_logic;
			carry_in:in std_logic;
			carry_out:out std_logic;
			Q:out std_logic_vector(3 downto 0)
			);
end BCD_counter;

architecture BCD_counter of BCD_counter is
	signal count:std_logic_vector(3 downto 0);
begin
	process(clk,reset)
	begin
		if reset = '1' then
			count <= "0000";
      elsif rising_edge(clk) then
         if carry_in = '1' then
				if M = '0' then
					if count = "1001" then
						count <= "0000";
               else
                  count <= count + 1;
               end if;

            else
               if count = "0000" then
                  count <= "1001";
               else
                  count <= count - 1;
               end if; 	
            end if;
         end if;
		end if;
	end process;
	
	carry_out <= '1' when
		(reset = '0') and (carry_in = '1') and ((M = '0' and count = "1001") or (M = '1' and count = "0000"))
      else '0';

   Q <= count;

end BCD_counter;
		