library verilog;
use verilog.vl_types.all;
entity addsub_3bits is
    port(
        a               : in     vl_logic_vector(2 downto 0);
        b               : in     vl_logic_vector(2 downto 0);
        ctrl            : in     vl_logic;
        s               : out    vl_logic_vector(2 downto 0);
        cout            : out    vl_logic
    );
end addsub_3bits;
