onerror {exit -code 1}
vlib work
vlog -work work F_3bit.vo
vlog -work work Waveform.vwf.vt
vsim -novopt -c -t 1ps -L cycloneiv_ver -L altera_ver -L altera_mf_ver -L 220model_ver -L sgate work.addsub_3bits_vlg_vec_tst -voptargs="+acc"
vcd file -direction F_3bit.msim.vcd
vcd add -internal addsub_3bits_vlg_vec_tst/*
vcd add -internal addsub_3bits_vlg_vec_tst/i1/*
run -all
quit -f
