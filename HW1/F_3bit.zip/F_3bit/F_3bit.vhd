library ieee;
use ieee.std_logic_1164.all;

entity addsub_3bits is
    port (
        a    : in  std_logic_vector(2 downto 0);
        b    : in  std_logic_vector(2 downto 0);
        ctrl : in  std_logic;
        s    : out std_logic_vector(2 downto 0);
        cout : out std_logic
    );
end addsub_3bits;

architecture addsub_3bits of addsub_3bits is
    signal bx : std_logic_vector(2 downto 0);
    signal c0, c1, c2, c3 : std_logic;
begin

    bx(0) <= b(0) xor ctrl;
    bx(1) <= b(1) xor ctrl;
    bx(2) <= b(2) xor ctrl;
    c0 <= ctrl;
	 
    s(0) <= a(0) xor bx(0) xor c0;
    c1 <= (a(0) and bx(0)) or
          (a(0) and c0) or
          (bx(0) and c0);

    s(1) <= a(1) xor bx(1) xor c1;
    c2 <= (a(1) and bx(1)) or
          (a(1) and c1) or
          (bx(1) and c1);

    s(2) <= a(2) xor bx(2) xor c2;
    c3 <= (a(2) and bx(2)) or
          (a(2) and c2) or
          (bx(2) and c2);
			 
    cout <= c3;
	 
end addsub_3bits;