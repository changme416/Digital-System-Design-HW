library ieee;
use ieee.std_logic_1164.all;

entity mul_3x3 is
    port (
        a, b : in  std_logic_vector(2 downto 0);
        p    : out std_logic_vector(5 downto 0)
    );
end mul_3x3;

architecture mul_3x3 of mul_3x3 is
    signal m0, m1, m2, m3, m4, m5, m6, m7, m8 : std_logic;
    signal x0, x1, x2, x3, x4 : std_logic;
    signal c1, c2, c3, d2, d3, d4 : std_logic;
begin
    m0 <= a(0) and b(0);
    m1 <= a(1) and b(0);
    m2 <= a(2) and b(0);

    m3 <= a(0) and b(1);
    m4 <= a(1) and b(1);
    m5 <= a(2) and b(1);

    m6 <= a(0) and b(2);
    m7 <= a(1) and b(2);
    m8 <= a(2) and b(2);

    x0 <= m0;

    x1 <= m1 xor m3;
    c1 <= m1 and m3;

    x2 <= m2 xor m4 xor c1;
    c2 <= (m2 and m4) or (m2 and c1) or (m4 and c1);

    x3 <= m5 xor c2;
    c3 <= m5 and c2;

    x4 <= c3;

    p(0) <= x0;
    p(1) <= x1;
    p(2) <= x2 xor m6;
    d2 <= x2 and m6;
    p(3) <= x3 xor m7 xor d2;
    d3 <= (x3 and m7) or (x3 and d2) or (m7 and d2);
    p(4) <= x4 xor m8 xor d3;
    d4 <= (x4 and m8) or (x4 and d3) or (m8 and d3);
    p(5) <= d4;

end mul_3x3;