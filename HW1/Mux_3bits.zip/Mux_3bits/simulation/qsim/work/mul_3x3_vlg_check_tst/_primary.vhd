library verilog;
use verilog.vl_types.all;
entity mul_3x3_vlg_check_tst is
    port(
        p               : in     vl_logic_vector(5 downto 0);
        sampler_rx      : in     vl_logic
    );
end mul_3x3_vlg_check_tst;
