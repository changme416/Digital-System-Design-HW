library verilog;
use verilog.vl_types.all;
entity mul_3x3 is
    port(
        a               : in     vl_logic_vector(2 downto 0);
        b               : in     vl_logic_vector(2 downto 0);
        p               : out    vl_logic_vector(5 downto 0)
    );
end mul_3x3;
