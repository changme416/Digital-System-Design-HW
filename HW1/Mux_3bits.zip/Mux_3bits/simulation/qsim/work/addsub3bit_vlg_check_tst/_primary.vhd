library verilog;
use verilog.vl_types.all;
entity addsub3bit_vlg_check_tst is
    port(
        cout            : in     vl_logic;
        s               : in     vl_logic_vector(2 downto 0);
        sampler_rx      : in     vl_logic
    );
end addsub3bit_vlg_check_tst;
