library verilog;
use verilog.vl_types.all;
entity addsub3bit_vlg_sample_tst is
    port(
        a               : in     vl_logic_vector(2 downto 0);
        b               : in     vl_logic_vector(2 downto 0);
        ctrl            : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end addsub3bit_vlg_sample_tst;
