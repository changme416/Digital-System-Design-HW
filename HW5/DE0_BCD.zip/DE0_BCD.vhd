library ieee;
use ieee.std_logic_1164.all;

entity DE0_BCD is
    generic (CLOCK_HZ : positive := 50000000);
    port (
        CLOCK_50, BUTTON0_N : in std_logic;
        SW : in std_logic_vector(2 downto 0);
        HEX0_D, HEX1_D, HEX2_D, HEX3_D : out std_logic_vector(6 downto 0);
        HEX_DP : out std_logic_vector(3 downto 0)
    );
end entity;

architecture rtl of DE0_BCD is
    type digit_array is array (0 to 3) of integer range 0 to 15;
    type display_array is array (0 to 3) of std_logic_vector(6 downto 0);
    signal digit : digit_array := (others => 0);
    signal display : display_array;
    signal rst_pipe : std_logic_vector(1 downto 0) := "11";
    signal sw_meta, sw_sync : std_logic_vector(2 downto 0) := "000";
    signal previous : std_logic_vector(2 downto 1) := "00";
    signal ticks : natural range 0 to CLOCK_HZ - 1 := 0;
    signal period : positive range 1 to CLOCK_HZ;
    signal last_digit : integer range 9 to 15;
begin
    assert CLOCK_HZ >= 100 and CLOCK_HZ mod 100 = 0
        report "CLOCK_HZ must be >= 100 and divisible by 100" severity failure;

    period <= CLOCK_HZ / 100 when sw_sync(2) = '0' else CLOCK_HZ;
    last_digit <= 9 when sw_sync(1) = '0' else 15;

    process(CLOCK_50, BUTTON0_N)
    begin
        if BUTTON0_N = '0' then
            rst_pipe <= "11";
        elsif rising_edge(CLOCK_50) then
            rst_pipe <= rst_pipe(0) & '0';
        end if;
    end process;

    process(CLOCK_50, rst_pipe)
    begin
        if rst_pipe(1) = '1' then
            sw_meta <= "000";
            sw_sync <= "000";
            previous <= "00";
            ticks <= 0;
            digit <= (others => 0);
        elsif rising_edge(CLOCK_50) then
            sw_meta <= SW;
            sw_sync <= sw_meta;
            previous <= sw_sync(2 downto 1);

            if sw_sync(1) /= previous(1) then
                digit <= (others => 0);
                ticks <= 0;
            elsif sw_sync(2) /= previous(2) then
                ticks <= 0;
            elsif ticks = period - 1 then
                ticks <= 0;
                for i in 0 to 3 loop
                    if sw_sync(0) = '0' then
                        if digit(i) < last_digit then
                            digit(i) <= digit(i) + 1;
                            exit;
                        end if;
                        digit(i) <= 0;
                    else
                        if digit(i) > 0 then
                            digit(i) <= digit(i) - 1;
                            exit;
                        end if;
                        digit(i) <= last_digit;
                    end if;
                end loop;
            else
                ticks <= ticks + 1;
            end if;
        end if;
    end process;

    decode : for i in 0 to 3 generate
        with digit(i) select display(i) <=
            "1000000" when 0,  "1111001" when 1,
            "0100100" when 2,  "0110000" when 3,
            "0011001" when 4,  "0010010" when 5,
            "0000010" when 6,  "1111000" when 7,
            "0000000" when 8,  "0010000" when 9,
            "0001000" when 10, "0000011" when 11,
            "1000110" when 12, "0100001" when 13,
            "0000110" when 14, "0001110" when 15;
    end generate;

    HEX0_D <= display(0);
    HEX1_D <= display(1);
    HEX2_D <= display(2);
    HEX3_D <= display(3);
    HEX_DP <= "1111";
end architecture;